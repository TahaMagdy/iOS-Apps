alartView
ImagePicker 
activityViewController 
