//
//  ViewController.swift
//  Roshambo
//

import UIKit

class StartingVC: UIViewController {

  

    
    
    
    
    
    
    // * Moving another View without segues
    @IBAction func paperPlay(_ sender: Any) {
        
        // 1 * From the storyboard, we instantiate an view
        //   which is connected to the resultVC
        
        // NOTE;
        //  >> the method instantiateViewConroller takes viewcontroller identifier
        //  >> specify an identifier to vc though the identify inspector.
        //  >> It's good to make the vc name = the identifier
        let nextView = self.storyboard?.instantiateViewController(withIdentifier: "ResultVC") as! ResultVC
        
        // 2 * Pass the data to the view
        nextView.choice = 2
        nextView.image = "paper"
        
        // After passing data to the created view
        // 3 * I move the cotrol to the created view
        self.present(nextView, animated: true, completion: nil)
        
    } // end paperPlay
    
    
    @IBAction func rockPlay(_ sender: Any) {
        performSegue(withIdentifier: "rockSague", sender: self)
    } // end rockPlay
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        // in case there are many segues.
        if segue.identifier == "rockSague" {
        // 1. Make the next view controller
        let nextView = segue.destination as! ResultVC
            
        // 2. Filling i
        nextView.choice = 1
        nextView.image = "rock"
            
        }
        
        // 2. Fill it with the important data
        
    }

} // end StartingVC

