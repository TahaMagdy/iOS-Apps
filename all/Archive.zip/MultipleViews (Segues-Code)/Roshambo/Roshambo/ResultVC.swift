//
//  ResultVC.swift
//  Roshambo
//


import UIKit

class ResultVC: UIViewController {

    
    // 1 -> rock
    // 2 -> paper
    // 0 -> scissors
    var choice:Int = 0
    var image:String = "scissors"
    @IBOutlet weak var resultPhrase: UILabel!
    @IBOutlet weak var resulyImage: UIImageView!
    
    
    override func viewDidLoad() {
        resulyImage.image = UIImage(named: image)
    }

    
    @IBAction func playAgain(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    } // end playAgain

} // end ResultVC Class
